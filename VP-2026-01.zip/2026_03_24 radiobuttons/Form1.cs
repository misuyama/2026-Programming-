﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2026_03_24_radiobuttons
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = " ";
            if (radioButton1.Checked == true)
            {
                a += "프랑크제국입니다.\n";
            }
            else if (radioButton2.Checked == true)
            {
                a += "신성로마제국입니다.\n";
            }
            else if (radioButton3.Checked == true)
            {
                a += "라틴제국입니다.\n";
            }

            if (radioButton4.Checked)
            {
                a += " 남자입니다.\n";
            }
            else if (radioButton5.Checked)
            {
                a += " 여자입니다.\n";
            }

            MessageBox.Show( a, "결과입니다.");
        }
    }
}
