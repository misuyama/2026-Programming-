﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace change_tempers
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
