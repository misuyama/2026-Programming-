﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2026_03_17_성적계산기
{
    public partial class 성적계산기 : Form
    {
        public 성적계산기()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //gkqrP는 합계를 의미한다. 합계 결론 gkqrP ruffhs
            double gkqrP = Convert.ToDouble(kr.Text) + Convert.ToDouble(math.Text) + Convert.ToDouble(engilsh.Text);
            double ruffhs = gkqrP / 3;

            sum.Text = gkqrP.ToString();
            mid.Text = ruffhs.ToString("0.0");



            
           
        }
    }
}
