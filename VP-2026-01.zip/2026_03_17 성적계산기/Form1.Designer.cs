﻿namespace _2026_03_17_성적계산기
{
    partial class 성적계산기
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.input = new System.Windows.Forms.GroupBox();
            this.result = new System.Windows.Forms.GroupBox();
            this.kr1 = new System.Windows.Forms.Label();
            this.kr = new System.Windows.Forms.TextBox();
            this.math = new System.Windows.Forms.TextBox();
            this.math1 = new System.Windows.Forms.Label();
            this.engilsh = new System.Windows.Forms.TextBox();
            this.engilsh1 = new System.Windows.Forms.Label();
            this.sum = new System.Windows.Forms.TextBox();
            this.sum1 = new System.Windows.Forms.Label();
            this.mid = new System.Windows.Forms.TextBox();
            this.mid1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.input.SuspendLayout();
            this.result.SuspendLayout();
            this.SuspendLayout();
            // 
            // input
            // 
            this.input.Controls.Add(this.engilsh);
            this.input.Controls.Add(this.engilsh1);
            this.input.Controls.Add(this.math);
            this.input.Controls.Add(this.math1);
            this.input.Controls.Add(this.kr);
            this.input.Controls.Add(this.kr1);
            this.input.Location = new System.Drawing.Point(52, 53);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(225, 212);
            this.input.TabIndex = 0;
            this.input.TabStop = false;
            this.input.Text = "성적입력";
            // 
            // result
            // 
            this.result.Controls.Add(this.mid);
            this.result.Controls.Add(this.mid1);
            this.result.Controls.Add(this.sum);
            this.result.Controls.Add(this.sum1);
            this.result.Location = new System.Drawing.Point(370, 80);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(200, 100);
            this.result.TabIndex = 1;
            this.result.TabStop = false;
            this.result.Text = "결과";
            // 
            // kr1
            // 
            this.kr1.AutoSize = true;
            this.kr1.Location = new System.Drawing.Point(25, 50);
            this.kr1.Name = "kr1";
            this.kr1.Size = new System.Drawing.Size(29, 12);
            this.kr1.TabIndex = 0;
            this.kr1.Text = "국어";
            // 
            // kr
            // 
            this.kr.Location = new System.Drawing.Point(100, 40);
            this.kr.Name = "kr";
            this.kr.Size = new System.Drawing.Size(100, 21);
            this.kr.TabIndex = 2;
            // 
            // math
            // 
            this.math.Location = new System.Drawing.Point(100, 95);
            this.math.Name = "math";
            this.math.Size = new System.Drawing.Size(100, 21);
            this.math.TabIndex = 4;
            // 
            // math1
            // 
            this.math1.AutoSize = true;
            this.math1.Location = new System.Drawing.Point(25, 98);
            this.math1.Name = "math1";
            this.math1.Size = new System.Drawing.Size(29, 12);
            this.math1.TabIndex = 3;
            this.math1.Text = "수학";
            // 
            // engilsh
            // 
            this.engilsh.Location = new System.Drawing.Point(100, 151);
            this.engilsh.Name = "engilsh";
            this.engilsh.Size = new System.Drawing.Size(100, 21);
            this.engilsh.TabIndex = 6;
            // 
            // engilsh1
            // 
            this.engilsh1.AutoSize = true;
            this.engilsh1.Location = new System.Drawing.Point(25, 151);
            this.engilsh1.Name = "engilsh1";
            this.engilsh1.Size = new System.Drawing.Size(29, 12);
            this.engilsh1.TabIndex = 5;
            this.engilsh1.Text = "영어";
            // 
            // sum
            // 
            this.sum.Location = new System.Drawing.Point(88, 27);
            this.sum.Name = "sum";
            this.sum.ReadOnly = true;
            this.sum.Size = new System.Drawing.Size(100, 21);
            this.sum.TabIndex = 4;
            // 
            // sum1
            // 
            this.sum1.AutoSize = true;
            this.sum1.Location = new System.Drawing.Point(6, 30);
            this.sum1.Name = "sum1";
            this.sum1.Size = new System.Drawing.Size(29, 12);
            this.sum1.TabIndex = 3;
            this.sum1.Text = "총점";
            // 
            // mid
            // 
            this.mid.Location = new System.Drawing.Point(86, 63);
            this.mid.Name = "mid";
            this.mid.ReadOnly = true;
            this.mid.Size = new System.Drawing.Size(102, 21);
            this.mid.TabIndex = 6;
            // 
            // mid1
            // 
            this.mid1.AutoSize = true;
            this.mid1.Location = new System.Drawing.Point(6, 66);
            this.mid1.Name = "mid1";
            this.mid1.Size = new System.Drawing.Size(29, 12);
            this.mid1.TabIndex = 5;
            this.mid1.Text = "평균";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(495, 242);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "입력";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // 성적계산기
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 296);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.result);
            this.Controls.Add(this.input);
            this.Name = "성적계산기";
            this.Text = "Form1";
            this.input.ResumeLayout(false);
            this.input.PerformLayout();
            this.result.ResumeLayout(false);
            this.result.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox input;
        private System.Windows.Forms.GroupBox result;
        private System.Windows.Forms.Label kr1;
        private System.Windows.Forms.TextBox engilsh;
        private System.Windows.Forms.Label engilsh1;
        private System.Windows.Forms.TextBox math;
        private System.Windows.Forms.Label math1;
        private System.Windows.Forms.TextBox kr;
        private System.Windows.Forms.TextBox mid;
        private System.Windows.Forms.Label mid1;
        private System.Windows.Forms.TextBox sum;
        private System.Windows.Forms.Label sum1;
        private System.Windows.Forms.Button button1;
    }
}

