﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _003___tempcombuts
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
